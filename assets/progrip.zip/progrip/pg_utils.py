# pg_utils.py

import bpy
from mathutils import Matrix, Vector, Euler

PG_PREFIX = "PG_"
EPS_ONE = 0.999
EPS_ZERO = 0.001

def is_pg_name(name: str) -> bool:
    return bool(name) and name.startswith(PG_PREFIX)

def ensure_scene_frame(scene: bpy.types.Scene, frame: int):
    scene.frame_set(int(frame))

def get_eval_armature(scene, arm_obj):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    arm_eval = arm_obj.evaluated_get(depsgraph)
    return arm_eval

def eval_matrix_world(obj: bpy.types.Object) -> Matrix:
    """Return evaluated matrix_world (after constraints), as a copy."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    return obj_eval.matrix_world.copy()

def bone_world_matrix(scene: bpy.types.Scene, arm_obj: bpy.types.Object, bone_name: str, frame: int) -> Matrix:
    ensure_scene_frame(scene, frame)
    arm_eval = get_eval_armature(scene, arm_obj)
    pb = arm_eval.pose.bones.get(bone_name)
    if pb is None:
        raise RuntimeError(f"Pose bone not found: {bone_name}")
    return arm_eval.matrix_world @ pb.matrix

def cursor_world_matrix(scene: bpy.types.Scene) -> Matrix:
    c = scene.cursor
    # Blender exposes cursor matrix in modern versions; fallback if not present.
    if hasattr(c, "matrix"):
        return c.matrix.copy()
    # fallback
    loc = c.location.copy()
    rot = c.rotation_euler.copy() if hasattr(c, "rotation_euler") else Euler((0,0,0))
    return Matrix.Translation(loc) @ rot.to_matrix().to_4x4()

def make_empty_domain(name: str, matrix_world: Matrix, collection=None) -> bpy.types.Object:
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = 'PLAIN_AXES'
    empty.matrix_world = matrix_world
    if collection is None:
        bpy.context.scene.collection.objects.link(empty)
    else:
        collection.objects.link(empty)
    return empty

def find_object(name: str):
    return bpy.data.objects.get(name)

def ensure_domain_collection() -> bpy.types.Collection:
    col_name = "PG_DOMAINS"
    col = bpy.data.collections.get(col_name)
    if col is None:
        col = bpy.data.collections.new(col_name)
        bpy.context.scene.collection.children.link(col)
        # Cosmetic default: keep domains out of the way.
        col.hide_viewport = True
        col.hide_render = True
    return col

def ensure_domain_for_prop(prop: bpy.types.Object) -> bpy.types.Object:
    # Reuse a stable "main" domain name for cleanliness.
    dom_name = f"{PG_PREFIX}DOM_{prop.name}"
    dom = bpy.data.objects.get(dom_name)
    if dom and dom.type == 'EMPTY':
        return dom
    col = ensure_domain_collection()
    dom = make_empty_domain(dom_name, prop.matrix_world.copy(), collection=col)
    return dom

def set_object_snap(obj: bpy.types.Object, target_mw: Matrix, snap_mode: str):
    # Snap object matrix_world to target (full), or loc-only, or rot-only.
    if snap_mode == "SNAP_LOC_ROT":
        obj.matrix_world = target_mw
        return

    loc_t, rot_t, sca_t = target_mw.decompose()
    loc_o, rot_o, sca_o = obj.matrix_world.decompose()

    if snap_mode == "SNAP_LOC_ONLY":
        loc = loc_t
        rot = rot_o
        sca = sca_o
    elif snap_mode == "SNAP_ROT_ONLY":
        loc = loc_o
        rot = rot_t
        sca = sca_o
    else:
        obj.matrix_world = target_mw
        return

    mw = Matrix.Translation(loc) @ rot.to_matrix().to_4x4()
    mw @= Matrix.Diagonal(Vector((sca.x, sca.y, sca.z, 1.0)))
    obj.matrix_world = mw

def keyframe_constraint_influence(con, frame: int):
    con.keyframe_insert(data_path="influence", frame=int(frame))

def is_influence_one(val: float) -> bool:
    return val >= EPS_ONE

def is_influence_zero(val: float) -> bool:
    return val <= EPS_ZERO