#__init__.py

bl_info = {
    "name": "ProGrip",
    "author": "David + ChatGPT",
    "version": (0, 1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > ProGrip",
    "description": "Grab and release props using domains and animated constraint influence (Blender 5.x).",
    "category": "Animation",
}

_modules = (
    "pg_properties",
    "pg_ops_grip",
    "pg_ops_release",
    "pg_ops_purge",
    "pg_ui",
)

_loaded = []


def register():
    import importlib
    from . import pg_properties  # base first (defines Scene.pg_settings)

    # Import in order (and keep refs for unregister)
    global _loaded
    _loaded = []

    for name in _modules:
        mod = importlib.import_module(f"{__name__}.{name}")
        _loaded.append(mod)

    # Register in the same order
    for mod in _loaded:
        if hasattr(mod, "register"):
            mod.register()


def unregister():
    # Unregister in reverse order
    global _loaded
    for mod in reversed(_loaded):
        if hasattr(mod, "unregister"):
            mod.unregister()
    _loaded = []