# progrippg_ui.py

import bpy
from bpy.types import Panel

class PG_PT_main(Panel):
    bl_label = "ProGrip"
    bl_idname = "PG_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ProGrip"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        s = scene.pg_settings

        col = layout.column(align=True)
        col.label(text="Targets")
        col.prop(s, "prop_object")
        col.prop(s, "armature_object")
        col.prop(s, "hand_bone")

        layout.separator()

        box = layout.box()
        box.label(text="Grip")
        row = box.row(align=True)
        row.prop(s, "contact_frame")
        #row.prop(s, "pre_offset")
        #box.operator("pg.create_grip_domain", icon='EMPTY_AXIS')
        box.operator("pg.apply_grip_animated", icon='KEY_HLT')
        box.operator("pg.instant_grab", icon='CON_TRANSFORM')

        layout.separator()

        box = layout.box()
        box.label(text="Release")
        row = box.row(align=True)
        row.prop(s, "release_frame")
        #row.prop(s, "pre_offset")
        #box.operator("pg.create_release_domain", icon='EMPTY_AXIS')
        box.operator("pg.apply_release_animated", icon='KEY_HLT')
        #box.operator("pg.instant_release", icon='CON_TRANSFORM')

        layout.separator()

        box = layout.box()
        row = box.row(align=True)
        icon = 'TRIA_DOWN' if s.ui_show_constraint_settings else 'TRIA_RIGHT'
        row.prop(s, "ui_show_constraint_settings", text="Constraint Settings", icon=icon, emboss=False)

        if s.ui_show_constraint_settings:
            box.label(text="Follow Rotation")
            box.prop(s, "channels_rot", text="")

            box.separator()
            box.prop(s, "fade_prev_active")
            box.prop(s, "instant_keyframe")
            box.prop(s, "snap_mode")

        layout.separator()

        danger = layout.box()
        danger.alert = True
        danger.label(text="Cleanup", icon='TRASH')
        danger.operator("pg.purge_scene", icon='CANCEL')

classes = (PG_PT_main,)

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)