# pg_properties.py

import bpy
from bpy.props import (
    PointerProperty,
    StringProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    BoolVectorProperty,
)
from bpy.types import PropertyGroup


SNAP_MODE_ITEMS = [
    ("SNAP_LOC_ROT", "Snap Loc+Rot", "Teleport object to match hand (location + rotation)"),
    ("SNAP_LOC_ONLY", "Snap Location Only", "Teleport object location only, keep current rotation"),
    ("SNAP_ROT_ONLY", "Snap Rotation Only", "Teleport object rotation only, keep current location"),
]

class PG_SceneSettings(PropertyGroup):
    prop_object: PointerProperty(
        name="Prop",
        type=bpy.types.Object,
        description="Object to grab/release",
    )
    armature_object: PointerProperty(
        name="Armature",
        type=bpy.types.Object,
        description="Armature that contains the hand bone",
    )
    hand_bone: StringProperty(
        name="Hand Bone",
        description="Name of the hand bone (pose bone) to drive the grab domain",
        default="",
    )

    contact_frame: IntProperty(
        name="Contact Frame",
        default=1,
        description="Frame where the grasp happens (influence becomes 1)",
    )
    release_frame: IntProperty(
        name="Release Frame",
        default=1,
        description="Frame where the release happens",
    )
    pre_offset: IntProperty(
        name="Pre Offset",
        default=1,
        min=0,
        description="Pre-Grasp/Pre-Release frame = Contact/Release - Pre Offset",
    )

    channels_rot: BoolVectorProperty(
        name="Follow Rotation",
        size=3,
        default=(True, True, True),
        description="Enable rotation follow per axis",
        subtype='XYZ',
    )

    ui_show_constraint_settings: BoolProperty(
        name="Constraint Settings",
        description="Show/hide advanced constraint settings",
        default=False,
    )

    fade_prev_active: BoolProperty(
        name="Fade Previous Active",
        default=True,
        description="When applying a new grab/release, fade out previous ProGrip constraints that are active (~1) on the event frame",
    )

    instant_keyframe: BoolProperty(
        name="Keyframe Instant",
        default=True,
        description="If enabled, Instant Grab/Release inserts influence keyframes on the current frame",
    )

    snap_mode: EnumProperty(
        name="Instant Snap Mode",
        items=SNAP_MODE_ITEMS,
        default="SNAP_LOC_ROT",
    )


classes = (PG_SceneSettings,)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pg_settings = PointerProperty(type=PG_SceneSettings)

def unregister():
    del bpy.types.Scene.pg_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)