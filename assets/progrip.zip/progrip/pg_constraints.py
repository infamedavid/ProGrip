import bpy
from mathutils import Matrix
from .pg_utils import PG_PREFIX

def _axis_apply_childof(con, loc_xyz, rot_xyz, scale_xyz):
    props = {
        "use_location_x": loc_xyz[0], "use_location_y": loc_xyz[1], "use_location_z": loc_xyz[2],
        "use_rotation_x": rot_xyz[0], "use_rotation_y": rot_xyz[1], "use_rotation_z": rot_xyz[2],
        "use_scale_x": scale_xyz[0], "use_scale_y": scale_xyz[1], "use_scale_z": scale_xyz[2],
    }
    for k, v in props.items():
        if hasattr(con, k):
            setattr(con, k, bool(v))

def _axis_apply_copy_loc(con, loc_xyz):
    for axis, key in zip(loc_xyz, ("use_x", "use_y", "use_z")):
        if hasattr(con, key):
            setattr(con, key, bool(axis))

def _axis_apply_copy_rot(con, rot_xyz):
    for axis, key in zip(rot_xyz, ("use_x", "use_y", "use_z")):
        if hasattr(con, key):
            setattr(con, key, bool(axis))

def _axis_apply_copy_scale(con, scale_xyz):
    for axis, key in zip(scale_xyz, ("use_x", "use_y", "use_z")):
        if hasattr(con, key):
            setattr(con, key, bool(axis))

def pg_childof_set_inverse(owner_obj: bpy.types.Object, constraint_name: str):
    """
    Blender 5.x compatible: uses context.temp_override instead of legacy override dict.
    Executes the real 'Set Inverse' for a Child Of constraint.
    """
    con = owner_obj.constraints.get(constraint_name)
    if not con or con.type != 'CHILD_OF':
        return

    view_layer = bpy.context.view_layer
    prev_active = view_layer.objects.active
    prev_selected = [o for o in view_layer.objects if o.select_get()]

    try:
        # minimize side-effects
        for o in prev_selected:
            o.select_set(False)

        owner_obj.select_set(True)
        view_layer.objects.active = owner_obj
        owner_obj.constraints.active = con

        # Blender 5: must use temp_override (no override dict arg)
        with bpy.context.temp_override(object=owner_obj, active_object=owner_obj):
            # Some Blender builds expose 'owner' enum; some don't.
            # We'll try the most complete call first, then fallback.
            try:
                bpy.ops.constraint.childof_set_inverse(constraint=con.name, owner='OBJECT')
            except TypeError:
                bpy.ops.constraint.childof_set_inverse(constraint=con.name)

    finally:
        owner_obj.select_set(False)
        for o in prev_selected:
            if o and o.name in bpy.data.objects:
                o.select_set(True)
        if prev_active and prev_active.name in bpy.data.objects:
            view_layer.objects.active = prev_active


def set_inverse_childof(owner_obj: bpy.types.Object, con: bpy.types.Constraint, target_world: Matrix):
    con.inverse_matrix = target_world.inverted() @ owner_obj.matrix_world

def add_childof(owner_obj, name, target_obj, subtarget="", loc_xyz=(True,True,True), rot_xyz=(True,True,True), scale_xyz=(False,False,False)):
    con = owner_obj.constraints.new(type="CHILD_OF")
    con.name = f"{PG_PREFIX}{name}"
    con.target = target_obj
    if subtarget:
        con.subtarget = subtarget
    _axis_apply_childof(con, loc_xyz, rot_xyz, scale_xyz)
    return con

def add_copy_transforms(owner_obj, name, target_obj, subtarget=""):
    con = owner_obj.constraints.new(type="COPY_TRANSFORMS")
    con.name = f"{PG_PREFIX}{name}"
    con.target = target_obj
    if subtarget:
        con.subtarget = subtarget
    return con

def add_copy_loc_rot(owner_obj, name_prefix, target_obj, subtarget="", loc_xyz=(True,True,True), rot_xyz=(True,True,True), scale_xyz=(False,False,False)):
    con_loc = owner_obj.constraints.new(type="COPY_LOCATION")
    con_loc.name = f"{PG_PREFIX}{name_prefix}_LOC"
    con_loc.target = target_obj
    if subtarget:
        con_loc.subtarget = subtarget
    _axis_apply_copy_loc(con_loc, loc_xyz)

    con_rot = owner_obj.constraints.new(type="COPY_ROTATION")
    con_rot.name = f"{PG_PREFIX}{name_prefix}_ROT"
    con_rot.target = target_obj
    if subtarget:
        con_rot.subtarget = subtarget
    _axis_apply_copy_rot(con_rot, rot_xyz)

    con_sca = None
    if any(scale_xyz):
        con_sca = owner_obj.constraints.new(type="COPY_SCALE")
        con_sca.name = f"{PG_PREFIX}{name_prefix}_SCL"
        con_sca.target = target_obj
        if subtarget:
            con_sca.subtarget = subtarget
        _axis_apply_copy_scale(con_sca, scale_xyz)

    return con_loc, con_rot, con_sca