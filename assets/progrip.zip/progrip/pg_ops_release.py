#  pg_ops_release.py

import bpy
from bpy.types import Operator

from .pg_utils import (
    ensure_scene_frame,
    cursor_world_matrix,
    ensure_domain_for_prop,
    set_object_snap,
    keyframe_constraint_influence,
    eval_matrix_world,
    is_pg_name,
    is_influence_one,
)
from .pg_constraints import add_copy_transforms

def _fade_prev_active_pg_constraints(scene, owner_obj, event_frame: int, pre_frame: int, exclude_names: set):
    current = scene.frame_current
    try:
        ensure_scene_frame(scene, event_frame)
        for con in owner_obj.constraints:
            if not is_pg_name(con.name):
                continue
            if con.name in exclude_names:
                continue
            if hasattr(con, "influence") and is_influence_one(float(con.influence)):
                ensure_scene_frame(scene, pre_frame)
                con.influence = 1.0
                keyframe_constraint_influence(con, pre_frame)
                ensure_scene_frame(scene, event_frame)
                con.influence = 0.0
                keyframe_constraint_influence(con, event_frame)
    finally:
        ensure_scene_frame(scene, current)

def _ensure_release_domain(scene, prop):
    col = bpy.data.collections.get("PG_DOMAINS")
    if col is None:
        col = bpy.data.collections.new("PG_DOMAINS")
        scene.collection.children.link(col)

    # Cosmetic default: keep domains out of the way.
    col.hide_viewport = True
    col.hide_render = True

    # Stable name: one release domain per prop.
    name = f"PG_REL_{prop.name}"
    dom = bpy.data.objects.get(name)
    if dom and dom.type == 'EMPTY':
        return dom

    mw = cursor_world_matrix(scene)
    dom = bpy.data.objects.new(name, None)
    dom.empty_display_type = 'SPHERE'
    dom.matrix_world = mw
    col.objects.link(dom)
    return dom

class PG_OT_create_release_domain_at_cursor(Operator):
    bl_idname = "pg.create_release_domain"
    bl_label = "Create Release Domain (Cursor)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings
        prop = s.prop_object or context.object
        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}

        dom = _ensure_release_domain(scene, prop)
        self.report({'INFO'}, f"Release domain: {dom.name}")
        return {'FINISHED'}

class PG_OT_apply_release_animated(Operator):
    bl_idname = "pg.apply_release_animated"
    bl_label = "Apply Release (Animated)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings
        prop = s.prop_object or context.object
        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}

        release = int(s.release_frame) if s.release_frame else scene.frame_current
        pre = release - 1

        # Core paradigm:
        # - Object keeps Child Of (Set Inverse) to Grip Domain forever.
        # - On release, we stop driving the Grip Domain from the hand and start driving it from a Release Domain.
        grip_dom = ensure_domain_for_prop(prop)
        rel_dom = _ensure_release_domain(scene, prop)

        # At the release frame, snap the Release Domain to the evaluated Grip Domain.
        ensure_scene_frame(scene, release)
        rel_dom.matrix_world = eval_matrix_world(grip_dom)
        rel_dom.keyframe_insert(data_path="location", frame=release)
        rel_dom.keyframe_insert(data_path="rotation_euler", frame=release)
        rel_dom.keyframe_insert(data_path="scale", frame=release)

        created = set()

        # Ensure (or create) Release->GripDomain driver
        con_rel = grip_dom.constraints.get("PG_CT_REL_TO_DOM")
        if con_rel is None or con_rel.type != 'COPY_TRANSFORMS':
            con_rel = add_copy_transforms(grip_dom, "CT_REL_TO_DOM", rel_dom)
        else:
            con_rel.target = rel_dom
        created.add(con_rel.name)

        # Find the existing Hand->GripDomain constraint created by the grab operators.
        con_hand = grip_dom.constraints.get("PG_CT_HAND_TO_DOM")
        if con_hand is None:
            # Fallback: grab the first PG_* Copy Transforms that targets an Armature bone.
            for c in grip_dom.constraints:
                if not is_pg_name(c.name):
                    continue
                if c.type == 'COPY_TRANSFORMS' and getattr(c, "subtarget", ""):
                    con_hand = c
                    break

        if con_hand is None:
            self.report({'ERROR'}, "No hand->domain constraint found. Apply Grip first.")
            return {'CANCELLED'}

        # 1-frame handoff
        ensure_scene_frame(scene, pre)
        con_hand.influence = 1.0
        keyframe_constraint_influence(con_hand, pre)
        con_rel.influence = 0.0
        keyframe_constraint_influence(con_rel, pre)

        ensure_scene_frame(scene, release)
        con_hand.influence = 0.0
        keyframe_constraint_influence(con_hand, release)
        con_rel.influence = 1.0
        keyframe_constraint_influence(con_rel, release)

        # Optional: fade other active PG constraints on the grip domain (not the object)
        if s.fade_prev_active:
            _fade_prev_active_pg_constraints(scene, grip_dom, event_frame=release, pre_frame=pre, exclude_names={con_hand.name, con_rel.name})

        self.report({'INFO'}, f"Release applied at {release} (handoff {pre}->{release})")
        return {'FINISHED'}

class PG_OT_instant_release(Operator):
    bl_idname = "pg.instant_release"
    bl_label = "Instant Release (Snap)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings
        prop = s.prop_object or context.object
        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}

        F = scene.frame_current
        pre = F - 1

        grip_dom = ensure_domain_for_prop(prop)
        rel_dom = _ensure_release_domain(scene, prop)

        ensure_scene_frame(scene, F)
        rel_dom.matrix_world = eval_matrix_world(grip_dom)
        rel_dom.keyframe_insert(data_path="location", frame=F)
        rel_dom.keyframe_insert(data_path="rotation_euler", frame=F)
        rel_dom.keyframe_insert(data_path="scale", frame=F)

        con_rel = grip_dom.constraints.get("PG_CT_REL_TO_DOM")
        if con_rel is None or con_rel.type != 'COPY_TRANSFORMS':
            con_rel = add_copy_transforms(grip_dom, "CT_REL_TO_DOM", rel_dom)
        else:
            con_rel.target = rel_dom

        con_hand = grip_dom.constraints.get("PG_CT_HAND_TO_DOM")
        if con_hand is None:
            for c in grip_dom.constraints:
                if is_pg_name(c.name) and c.type == 'COPY_TRANSFORMS' and getattr(c, "subtarget", ""):
                    con_hand = c
                    break

        if con_hand is None:
            self.report({'ERROR'}, "No hand->domain constraint found. Apply Grip first.")
            return {'CANCELLED'}

        # 1-frame handoff. For instant, only insert keys if requested.
        con_hand.influence = 0.0
        con_rel.influence = 1.0

        if s.instant_keyframe:
            # Insert a proper step (pre->F)
            ensure_scene_frame(scene, pre)
            con_hand.influence = 1.0
            keyframe_constraint_influence(con_hand, pre)
            con_rel.influence = 0.0
            keyframe_constraint_influence(con_rel, pre)

            ensure_scene_frame(scene, F)
            con_hand.influence = 0.0
            keyframe_constraint_influence(con_hand, F)
            con_rel.influence = 1.0
            keyframe_constraint_influence(con_rel, F)

        if s.fade_prev_active:
            _fade_prev_active_pg_constraints(scene, grip_dom, event_frame=F, pre_frame=pre, exclude_names={con_hand.name, con_rel.name})

        self.report({'INFO'}, "Instant Release done (domain handoff).")
        return {'FINISHED'}

classes = (
    PG_OT_create_release_domain_at_cursor,
    PG_OT_apply_release_animated,
    PG_OT_instant_release,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)