#   pg_ops_purge.py

import bpy
from bpy.types import Operator
from .pg_utils import is_pg_name

class PG_OT_purge_scene(Operator):
    bl_idname = "pg.purge_scene"
    bl_label = "Purge ProGrip (Scene)"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene

        # 1) Remove PG_ constraints from all objects
        for obj in bpy.data.objects:
            if not hasattr(obj, "constraints"):
                continue
            to_remove = [c for c in obj.constraints if is_pg_name(c.name)]
            for c in to_remove:
                obj.constraints.remove(c)

        # 2) Remove PG_ empties (objects)
        pg_objs = [obj for obj in bpy.data.objects if is_pg_name(obj.name) and obj.type == 'EMPTY']
        for obj in pg_objs:
            bpy.data.objects.remove(obj, do_unlink=True)

        # 3) Optionally remove empty PG_DOMAINS collection
        col = bpy.data.collections.get("PG_DOMAINS")
        if col and len(col.objects) == 0 and len(col.children) == 0:
            bpy.data.collections.remove(col)

        self.report({'INFO'}, "ProGrip purged from scene (PG_ constraints + empties).")
        return {'FINISHED'}

classes = (PG_OT_purge_scene,)

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)