# pg_ops_grip.py

import bpy
from bpy.types import Operator
from bpy.props import BoolProperty

from .pg_utils import (
    ensure_scene_frame,
    bone_world_matrix,
    ensure_domain_for_prop,
    set_object_snap,
    keyframe_constraint_influence,
    is_pg_name,
    is_influence_one,
)
from .pg_constraints import (
    add_childof,
    add_copy_transforms,
    pg_childof_set_inverse,
)

def _fade_prev_active_pg_constraints(scene, owner_obj, event_frame: int, pre_frame: int, exclude_names: set):
    # Only fade constraints created by ProGrip (PG_) that are active (~1) on the event frame.
    current = scene.frame_current
    try:
        ensure_scene_frame(scene, event_frame)
        for con in owner_obj.constraints:
            if not is_pg_name(con.name):
                continue
            if con.name in exclude_names:
                continue
            if hasattr(con, "influence") and is_influence_one(float(con.influence)):
                # Pre: 1, Event: 0
                ensure_scene_frame(scene, pre_frame)
                con.influence = 1.0
                keyframe_constraint_influence(con, pre_frame)
                ensure_scene_frame(scene, event_frame)
                con.influence = 0.0
                keyframe_constraint_influence(con, event_frame)
    finally:
        ensure_scene_frame(scene, current)

class PG_OT_create_grip_domain(Operator):
    bl_idname = "pg.create_grip_domain"
    bl_label = "Create Grip Domain"
    bl_options = {'REGISTER', 'UNDO'}

    align_to_pregrasp: BoolProperty(
        name="Align to Pre-Grasp",
        default=True,
        description="Align the domain to the hand bone at Pre-Grasp (Contact - Pre Offset).",
    )

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings

        prop = s.prop_object or context.object
        arm = s.armature_object
        bone = s.hand_bone.strip()

        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}
        if not arm or arm.type != 'ARMATURE':
            self.report({'ERROR'}, "Select a valid Armature.")
            return {'CANCELLED'}
        if not bone:
            self.report({'ERROR'}, "Hand bone is empty.")
            return {'CANCELLED'}

        contact = int(s.contact_frame) if s.contact_frame else scene.frame_current
        pre = contact - int(s.pre_offset)

        dom = ensure_domain_for_prop(prop)

        frame_align = pre if self.align_to_pregrasp else contact
        mw = bone_world_matrix(scene, arm, bone, frame_align)
        dom.matrix_world = mw

        self.report({'INFO'}, f"Domain ready: {dom.name}")
        return {'FINISHED'}

class PG_OT_apply_grip_animated(Operator):
    bl_idname = "pg.apply_grip_animated"
    bl_label = "Apply Grip (Animated)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings

        prop = s.prop_object or context.object
        arm = s.armature_object
        bone = s.hand_bone.strip()

        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}
        if not arm or arm.type != 'ARMATURE':
            self.report({'ERROR'}, "Select a valid Armature.")
            return {'CANCELLED'}
        if not bone:
            self.report({'ERROR'}, "Hand bone is empty.")
            return {'CANCELLED'}

        contact = int(s.contact_frame) if s.contact_frame else scene.frame_current
        pre = contact - int(s.pre_offset)

        dom = ensure_domain_for_prop(prop)

        # Align domain to hand at pre-grasp.
        dom_mw_pre = bone_world_matrix(scene, arm, bone, pre)
        dom.matrix_world = dom_mw_pre

        # Paradigm (fixed):
        # - Hand/Bone drives the Grip Domain via Copy Transforms.
        # - Object follows the Grip Domain via Child Of + Set Inverse (axis control is here).
        loc_xyz = (True, True, True)
        rot_xyz = tuple(s.channels_rot)
        scl_xyz = (False, False, False)

        created_names = set()

        # 1) Hand -> Domain constraint (on domain) : Copy Transforms (fixed)
        con_dom = add_copy_transforms(dom, "CT_HAND_TO_DOM", arm, subtarget=bone)
        created_names.add(con_dom.name)
        ensure_scene_frame(scene, pre)
        con_dom.influence = 0.0
        keyframe_constraint_influence(con_dom, pre)
        ensure_scene_frame(scene, contact)
        con_dom.influence = 1.0
        keyframe_constraint_influence(con_dom, contact)

        # 2) Domain -> Object constraint (on object)
        con_obj = add_childof(prop, "CO_DOM_TO_OBJ", dom, subtarget="", loc_xyz=loc_xyz, rot_xyz=rot_xyz, scale_xyz=scl_xyz)
        pg_childof_set_inverse(prop, con_obj.name)
        created_names.add(con_obj.name)

        ensure_scene_frame(scene, pre)
        con_obj.influence = 0.0
        keyframe_constraint_influence(con_obj, pre)
        ensure_scene_frame(scene, contact)
        con_obj.influence = 1.0
        keyframe_constraint_influence(con_obj, contact)

        # Fade previous active constraints (only those at ~1 on contact)
        if s.fade_prev_active:
            _fade_prev_active_pg_constraints(scene, dom, event_frame=contact, pre_frame=pre, exclude_names=created_names)
            _fade_prev_active_pg_constraints(scene, prop, event_frame=contact, pre_frame=pre, exclude_names=created_names)

        self.report({'INFO'}, f"Grip applied at {contact} (pre {pre})")
        return {'FINISHED'}

class PG_OT_instant_grab(Operator):
    bl_idname = "pg.instant_grab"
    bl_label = "Instant Grab (Snap)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        s = scene.pg_settings

        prop = s.prop_object or context.object
        arm = s.armature_object
        bone = s.hand_bone.strip()

        if not prop:
            self.report({'ERROR'}, "No prop object selected.")
            return {'CANCELLED'}
        if not arm or arm.type != 'ARMATURE':
            self.report({'ERROR'}, "Select a valid Armature.")
            return {'CANCELLED'}
        if not bone:
            self.report({'ERROR'}, "Hand bone is empty.")
            return {'CANCELLED'}

        F = scene.frame_current
        dom = ensure_domain_for_prop(prop)

        # Align domain to hand now
        dom_mw = bone_world_matrix(scene, arm, bone, F)
        dom.matrix_world = dom_mw

        # Snap object to domain (teleport) to avoid offsets
        set_object_snap(prop, dom.matrix_world.copy(), s.snap_mode)

        loc_xyz = (True, True, True)
        rot_xyz = tuple(s.channels_rot)
        scl_xyz = (False, False, False)

        created_names = set()

        # Hand -> Domain : Copy Transforms (fixed)
        con_dom = add_copy_transforms(dom, "CT_HAND_TO_DOM", arm, subtarget=bone)
        created_names.add(con_dom.name)
        con_dom.influence = 1.0
        if s.instant_keyframe:
            con_dom.keyframe_insert(data_path="influence", frame=F)

        # Domain -> Object (always Child Of for axis control)
        con_obj = add_childof(prop, "CO_DOM_TO_OBJ", dom, loc_xyz=loc_xyz, rot_xyz=rot_xyz, scale_xyz=scl_xyz)
        pg_childof_set_inverse(prop, con_obj.name)
        created_names.add(con_obj.name)
        con_obj.influence = 1.0
        if s.instant_keyframe:
            con_obj.keyframe_insert(data_path="influence", frame=F)

        # Fade previous active constraints (only those at ~1)
        if s.fade_prev_active:
            pre = F - int(s.pre_offset)
            _fade_prev_active_pg_constraints(scene, dom, event_frame=F, pre_frame=pre, exclude_names=created_names)
            _fade_prev_active_pg_constraints(scene, prop, event_frame=F, pre_frame=pre, exclude_names=created_names)

        self.report({'INFO'}, "Instant Grab done.")
        return {'FINISHED'}


classes = (
    PG_OT_create_grip_domain,
    PG_OT_apply_grip_animated,
    PG_OT_instant_grab,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)